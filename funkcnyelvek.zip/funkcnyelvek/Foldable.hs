data Single a = Single a deriving (Eq, Show)
data Tuple a = Tuple a a deriving (Eq, Show)
data Quintuple a = Quintuple a a a a a deriving (Eq, Show)
data List a = Nil | Cons a (List a) deriving (Eq, Show)
data Maybe a = Just a | Nothing deriving (Eq, Show)
data NonEmpty a = Last a | NECons a (NonEmpty a) deriving (Eq, Show)
data NonEmpty2 a = NECons2 a (List a) deriving (Eq, Show)
data Tree a = Leaf a | Node (Tree a) a (Tree a) deriving (Eq, Show)
data Either e a = Left e | Right a deriving (Eq, Show)
data BiTuple e a = BiTuple e a deriving (Eq, Show)
data TriEither e1 e2 a = LeftT e1 | MiddleT e2 | RightT a deriving (Eq, Show)
data BiList a b = ACons a (BiList a b) | BCons b (BiList a b) | ABNill deriving (Eq, Show)
data Apply f a = MkApply (f a) deriving (Eq, Show)
data Fix f a = MkFix (f (Fix f a))
data Compose f g a = MkCompose (f (g a)) deriving (Eq, Show)
data Sum f a b = FLeft (f a) | FRight (f b) deriving (Eq, Show)
data Prod f a b = FProd (f a) (f b) deriving (Eq, Show)
data FList f a = FNil | FCons (f a) (f (FList f a))
data Tree2 a = Leaf2 | Node2 (Tree2 a) a (Tree2 a) deriving (Eq, Show)
data RoseTree a = RoseLeaf a | RoseNode [RoseTree a] deriving (Eq, Show)
data Tree3 a = Leaf3 a | Node3 (Tree3 a) (Tree3 a) deriving (Eq, Show)
data SkipList a = Skip (SkipList a) | SCons a (SkipList a) | SNill deriving (Eq, Show)
data CrazyType a = C1 a a | C2 a Int | C3 (CrazyType a) deriving (Eq, Show)
data Either3 a b c = Left3 a | Middle3 b | Right3 c deriving (Eq, Show)
data Triplet a b c = Triplet a b c deriving (Eq, Show)
data SplitTree a b = SplitTree (Tree a) a b (Tree b) deriving (Eq, Show)
data TriCompose f g h a = TriCompose (f (g (h a))) deriving (Eq, Show)
data Free f a = Pure a | Free (f (Free f a))

instance Foldable Single where
  foldr f b (Single a) = f a b
  foldMap f (Single a) = f a

instance Foldable Tuple where
  foldr f b (Tuple a1 a2) = f a1 (f a2 b)
  foldMap f (Tuple a1 a2) = f a1 <> f a2

instance Foldable Quintuple where
  foldr f b (Quintuple a b2 c d e) = f a (f b2 (f c (f d (f e b))))
  foldMap f (Quintuple a b2 c d e) = f a <> f b2 <> f c <> f d <> f e

instance Foldable List where
  foldr f b Nil = b
  foldr f b (Cons a l) = f a (foldr f b l)
  foldMap f Nil = mempty
  foldMap f (Cons a l) = f a <> foldMap f l

instance Foldable Maybe where
  foldr f b Nothing = b
  foldr f b (Just a) = f a b
  foldMap f Nothing = mempty
  foldMap f (Just a) = f a

instance Foldable NonEmpty where
  foldr f b (Last a) = f a b
  foldr f b (NECons a n) = f a (foldr f b n)
  foldMap f (Last a) = f a
  foldMap f (NECons a n) = f a <> foldMap f n

instance Foldable NonEmpty2 where
  foldr f b (NECons2 a l) = f a (foldr f b l)
  foldMap f (NECons2 a l) = f a <> foldMap f l

instance Foldable Tree where
  foldr f b (Leaf a) = f a b
  foldr f b (Node t1 a t2) = foldr f (f a (foldr f b t2)) t1
  foldMap f (Leaf a) = f a
  foldMap f (Node t1 a t2) = foldMap f t1 <> f a <> foldMap f t2

instance Foldable (Either fixed) where
  foldr f b (Left _) = b
  foldr f b (Right a) = f a b
  foldMap f (Left _) = mempty
  foldMap f (Right a) = f a

instance Foldable (BiTuple fixed) where
  foldr f b (BiTuple _ a) = f a b
  foldMap f (BiTuple _ a) = f a

instance Foldable (TriEither fixed1 fixed2) where
  foldr f b (LeftT _) = b
  foldr f b (MiddleT _) = b
  foldr f b (RightT a) = f a b
  foldMap f (LeftT _) = mempty
  foldMap f (MiddleT _) = mempty
  foldMap f (RightT a) = f a

instance Foldable (BiList fixed) where
  foldr f b ABNill = b
  foldr f b (ACons _ bl) = foldr f b bl
  foldr f b (BCons b1 bl) = f b1 (foldr f b bl)
  foldMap f ABNill = mempty
  foldMap f (ACons _ bl) = foldMap f bl
  foldMap f (BCons b1 bl) = f b1 <> foldMap f bl

instance Foldable f => Foldable (Apply f) where
  foldr f b (MkApply fa) = foldr f b fa
  foldMap f (MkApply fa) = foldMap f fa

instance (Foldable f, Foldable g) => Foldable (Compose f g) where
  foldr f b (MkCompose fga) = foldr (flip (foldr f)) b fga
  foldMap f (MkCompose fga) = foldMap (foldMap f) fga

instance Foldable f => Foldable (Sum f a) where
  foldr f b (FLeft _) = b
  foldr f b (FRight fb) = foldr f b fb
  foldMap f (FLeft _) = mempty
  foldMap f (FRight fb) = foldMap f fb

instance Foldable f => Foldable (Prod f a) where
  foldr f b (FProd _ fb) = foldr f b fb
  foldMap f (FProd _ fb) = foldMap f fb

instance Foldable f => Foldable (FList f) where
  foldr f b FNil = b
  foldr f b (FCons fa fflist) = foldr f (foldr f b fflist) fa
  foldMap f FNil = mempty
  foldMap f (FCons fa fflist) = foldMap f fa <> foldMap f fflist

instance Foldable Tree2 where
  foldr f b Leaf2 = b
  foldr f b (Node2 t1 a t2) = foldr f (f a (foldr f b t2)) t1
  foldMap f Leaf2 = mempty
  foldMap f (Node2 t1 a t2) = foldMap f t1 <> f a <> foldMap f t2

instance Foldable RoseTree where
  foldr f b (RoseLeaf a) = f a b
  foldr f b (RoseNode ts) = foldr (\t acc -> foldr f acc t) b ts
  foldMap f (RoseLeaf a) = f a
  foldMap f (RoseNode ts) = foldMap (foldMap f) ts

instance Foldable Tree3 where
  foldr f b (Leaf3 a) = f a b
  foldr f b (Node3 t1 t2) = foldr f (foldr f b t2) t1
  foldMap f (Leaf3 a) = f a
  foldMap f (Node3 t1 t2) = foldMap f t1 <> foldMap f t2

instance Foldable SkipList where
  foldr f b SNill = b
  foldr f b (Skip s) = foldr f b s
  foldr f b (SCons a s) = f a (foldr f b s)
  foldMap f SNill = mempty
  foldMap f (Skip s) = foldMap f s
  foldMap f (SCons a s) = f a <> foldMap f s

instance Foldable CrazyType where
  foldr f b (C1 a1 a2) = f a1 (f a2 b)
  foldr f b (C2 a _) = f a b
  foldr f b (C3 c) = foldr f b c
  foldMap f (C1 a1 a2) = f a1 <> f a2
  foldMap f (C2 a _) = f a
  foldMap f (C3 c) = foldMap f c

instance Foldable (Either3 fixed1 fixed2) where
  foldr f b (Left3 _) = b
  foldr f b (Middle3 _) = b
  foldr f b (Right3 a) = f a b
  foldMap f (Left3 _) = mempty
  foldMap f (Middle3 _) = mempty
  foldMap f (Right3 a) = f a

instance Foldable (Triplet fixed1 fixed2) where
  foldr f b (Triplet _ _ c) = f c b
  foldMap f (Triplet _ _ c) = f c

instance Foldable (SplitTree fixed) where
  foldr f b (SplitTree _ _ b' t2) = f b' (foldr f b t2)
  foldMap f (SplitTree _ _ b' t2) = f b' <> foldMap f t2
