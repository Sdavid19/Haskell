{-# LANGUAGE InstanceSigs, QuantifiedConstraints, StandaloneDeriving, StandaloneKindSignatures #-}
{-# OPTIONS_GHC -Wincomplete-patterns #-}

module Functorok where

import Prelude hiding (Either (..), Maybe (..))

-- A Functor egy alapfogalom Haskellben (és általában a funkcionális programozásban), 
-- amely arra szolgál, hogy egy "konténerben" lévő értékekre alkalmazzunk függvényeket, anélkül hogy kibontanánk a konténert.


--Egyszerű típusok
data Single a = Single a deriving (Eq, Show)
instance Functor Single where
    fmap :: (a -> b) -> Single a -> Single b
    fmap f (Single a) = Single (f a)


data Tuple a = Tuple a a deriving (Eq, Show)
instance Functor Tuple where
    fmap f (Tuple a1 a2) = Tuple (f a1) (f a2)


data Quintuple a = Quintuple a a a a a deriving (Eq, Show)
instance Functor Quintuple where
    fmap f (Quintuple a b c d e) = Quintuple (f a) (f b) (f c) (f d) (f e)


data List a = Nil | Cons a (List a) deriving (Eq, Show)
instance Functor List where
    fmap f Nil = Nil
    fmap f (Cons a l) = Cons (f a) (fmap f l)


data Maybe a = Just a | Nothing deriving (Eq, Show)
instance Functor Maybe where
    fmap f Nothing = Nothing
    fmap f (Just a) = Just (f a)


data NonEmpty a = Last a | NECons a (NonEmpty a) deriving (Eq, Show)
instance Functor NonEmpty where
    fmap f (Last a) = Last (f a)
    fmap f (NECons a n) = NECons (f a) (fmap f n)


data NonEmpty2 a = NECons2 a (List a) deriving (Eq, Show)
instance Functor NonEmpty2 where
    fmap f (NECons2 a l) = NECons2 (f a) (fmap f l)

--fixálás
data Either e a = Left e | Right a deriving (Eq, Show)
instance Functor (Either fixed) where
    fmap f (Left fixed) = Left fixed
    fmap f (Right a) = Right (f a)

data BiTuple e a = BiTuple e a deriving (Eq, Show)
instance Functor (BiTuple fixed) where
    fmap f (BiTuple fixed a) = BiTuple fixed (f a)

--dupla fixálás
data TriEither e1 e2 a = LeftT e1 | MiddleT e2 | RightT a deriving (Eq, Show)
instance Functor (TriEither fixed1 fixed2) where
    fmap f (LeftT fixed) = (LeftT fixed)
    fmap f (MiddleT fixed) = (MiddleT fixed)
    fmap f (RightT a) = (RightT (f a))

data BiList a b = ACons a (BiList a b) | BCons b (BiList a b) | ABNill deriving (Eq, Show)
instance Functor (BiList fixed) where
    fmap f (ACons a bl) = (ACons a (fmap f bl))
    fmap f (BCons b bl) = (BCons (f b) (fmap f bl))
    fmap f (ABNill) = ABNill

data Tree a = Leaf | Node (Tree a) a (Tree a) deriving (Eq, Show)
instance Functor Tree where
    fmap f Leaf = Leaf
    fmap f (Node t1 a t2) = Node (fmap f t1) (f a) (fmap f t2)

data RoseTree a = RoseLeaf a | RoseNode [RoseTree a] deriving (Eq, Show)
instance Functor RoseTree where
    fmap f (RoseLeaf a) = RoseLeaf (f a)
    fmap f (RoseNode []) = RoseNode []
    fmap f (RoseNode xs) = RoseNode (map (fmap f) xs)

data Tree2 a = Leaf2 a | Node2 (Tree2 a) (Tree2 a) deriving (Eq, Show)
instance Functor Tree2 where
    fmap f (Leaf2 a) = Leaf2 (f a)
    fmap f (Node2 t1 t2) = Node2 (fmap f t1) (fmap f t2)

data SkipList a = Skip (SkipList a) | SCons a (SkipList a) | SNill deriving (Eq, Show)
instance Functor SkipList where
    fmap f (Skip l) = Skip (fmap f l)
    fmap f (SCons a l) = SCons (f a) (fmap f l)
    fmap f (SNill) = SNill

data CrazyType a = C1 a a | C2 a Int | C3 (CrazyType a) deriving (Eq, Show)
instance Functor CrazyType where
    fmap f (C1 a1 a2) = (C1 (f a1) (f a2))
    fmap f (C2 a i) = C2 (f a) i
    fmap f (C3 c) = C3 (fmap f c)

data Either3 a b c = Left3 a | Middle3 b | Right3 c deriving (Eq, Show)
instance Functor (Either3 fixed1 fixed2) where
    fmap f (Left3 a) = Left3 a
    fmap f (Middle3 b) = Middle3 b
    fmap f (Right3 c) = Right3 (f c)

data Triplet a b c = Triplet a b c deriving (Eq, Show)
instance Functor (Triplet fixed1 fixed2) where
    fmap f (Triplet a b c) = Triplet a b (f c)

data SplitTree a b = SplitTree (Tree a) a b (Tree b) deriving (Eq, Show)
instance Functor (SplitTree fixed) where
    fmap f (SplitTree t1 a b t2) = SplitTree t1 a (f b) (fmap f t2) 

data TriCompose f g h a = TriCompose (f (g (h a))) deriving (Eq, Show)
instance (Functor f, Functor g, Functor h) => Functor (TriCompose f g h) where
    fmap f (TriCompose fgh) = TriCompose (fmap (fmap (fmap f)) fgh)

data Free f a = Pure a | Free (f (Free f a))
instance Functor f => Functor (Free f) where
    fmap f (Pure a) = Pure (f a)
    fmap f (Free ffa) = Free (fmap (fmap f) ffa)

type Fix :: (* -> *) -> * -> *
data Fix f a = Fix (f (Fix f a))
instance Functor f => Functor (Fix f) where
  fmap f (Fix ff) = Fix (fmap (fmap f) ff)

data Join a b = Join (a -> a -> b)
instance Functor (Join fixed) where
    fmap f (Join g) = Join (\x y -> f (g x y))

data CrazyType2 a b = SingleA a | SingleB b | Translate (a -> b)
instance Functor (CrazyType2 a) where
    fmap f (SingleA a) = SingleA a
    fmap f (SingleB b) = SingleB (f b)
    fmap f (Translate g) = Translate(\x -> f (g x)) 

