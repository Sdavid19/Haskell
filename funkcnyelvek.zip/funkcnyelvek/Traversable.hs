{-# LANGUAGE DeriveFoldable, DeriveFunctor, QuantifiedConstraints, StandaloneDeriving #-}
module Traversable where

import Prelude hiding (Maybe(..), Either(..))


data Single a = Single a deriving (Eq, Show, Functor, Foldable)
instance Traversable Single where
    traverse f (Single a) = Single <$> f a 


data Tuple a = Tuple a a deriving (Eq, Show, Functor, Foldable)
instance Traversable Tuple where
    traverse f (Tuple a1 a2) = Tuple <$> f a1 <*> f a2

data Quintuple a = Quintuple a a a a a deriving (Eq, Show, Functor, Foldable)
instance Traversable Quintuple where
    traverse f (Quintuple a b c d e) = Quintuple <$> f a <*> f b <*> f c <*> f d <*> f e 

data List a = Nil | Cons a (List a) deriving (Eq, Show, Functor, Foldable)
instance Traversable List where
    traverse f (Nil) = pure Nil
    traverse f (Cons a l) = Cons <$> f a <*> traverse f l

data Maybe a = Just a | Nothing deriving (Eq, Show, Functor, Foldable)
instance Traversable Maybe where
    traverse f (Nothing) = pure Nothing
    traverse f (Just a) = Just <$> f a

data NonEmpty a = Last a | NECons a (NonEmpty a) deriving (Eq, Show, Functor, Foldable)
instance Traversable NonEmpty where
    traverse f (Last a) = Last <$> f a
    traverse f (NECons a n) = NECons <$> f a <*> traverse f n

data NonEmpty2 a = NECons2 a (List a) deriving (Eq, Show, Functor, Foldable)
instance Traversable NonEmpty2 where
    traverse f (NECons2 a l) = NECons2 <$> f a <*> traverse f l

data Tree a = Leaf a | Node (Tree a) a (Tree a) deriving (Eq, Show, Functor, Foldable)
instance Traversable Tree where
    traverse f (Leaf a) = Leaf <$> f a
    traverse f (Node t1 a t2) = Node <$> traverse f t1 <*> f a <*> traverse f t2

data Either e a = Left e | Right a deriving (Eq, Show, Functor, Foldable)
instance Traversable (Either fixed) where
    traverse f (Left e) = pure (Left e)
    traverse f (Right a) = Right <$> f a    

data BiTuple e a = BiTuple e a deriving (Eq, Show, Functor, Foldable)
instance Traversable (BiTuple fixed) where
    traverse f (BiTuple e a) = (BiTuple e) <$> f a

data TriEither e1 e2 a = LeftT e1 | MiddleT e2 | RightT a deriving (Eq, Show, Functor, Foldable)
instance Traversable (TriEither f1 f2) where
    traverse f (LeftT e) = pure (LeftT e)
    traverse f (MiddleT e) = pure (MiddleT e)
    traverse f (RightT a) = RightT <$> f a

data BiList a b = ACons a (BiList a b) | BCons b (BiList a b) | ABNill deriving (Eq, Show, Functor, Foldable)
instance Traversable (BiList fixed) where
    traverse f (ACons a b) = ACons a <$> traverse f b 
    traverse f (BCons b bl) = BCons <$> f b <*> traverse f bl
    traverse f (ABNill) = pure (ABNill)

data Apply f a = MkApply (f a) deriving (Eq, Show, Functor, Foldable)
instance Traversable f => Traversable (Apply f) where
    traverse f (MkApply fa) = MkApply <$> traverse f fa

data Compose f g a = MkCompose (f (g a)) deriving (Eq, Show, Functor, Foldable)
instance (Traversable f, Traversable g) => Traversable (Compose f g) where
  traverse f (MkCompose fga) = MkCompose <$> traverse (traverse f) fga

data Sum f a b = FLeft (f a) | FRight (f b)  deriving (Eq, Show, Functor, Foldable)
instance (Traversable f) => Traversable (Sum f a) where
  traverse f (FLeft fa)  = pure (FLeft fa)
  traverse f (FRight fb) = FRight <$> traverse f fb

data Prod f a b = FProd (f a) (f b)  deriving (Eq, Show, Functor, Foldable)
instance (Traversable f) => Traversable (Prod f a) where
  traverse h (FProd fa fb) = FProd fa <$> traverse h fb

data FList f a = FNil | FCons (f a) (f (FList f a)) deriving (Eq, Show, Functor, Foldable)
instance (Traversable f) => Traversable (FList f) where
  traverse h FNil = pure FNil
  traverse h (FCons fa fflist) =
    FCons <$> traverse h fa <*> traverse (traverse h) fflist
