module RopZH2 where

data CrazyType4 a b = CT1 a b a | CT2 b b Int deriving Eq

data CrazyType3 f a b = C1 (f a) (f b) | C2 a b b | C3 (CrazyType3 f a b) b deriving Eq

instance Functor (CrazyType4 fixed1) where
    fmap :: (a -> b) -> CrazyType4 fixed1 a -> CrazyType4 fixed1 b
    fmap f (CT1 f1 a b) = CT1 f1 (f a) b
    fmap f (CT2 f1 b i) = CT2 (f f1) (f b) i

instance Functor f => Functor (CrazyType3 f fixed) where
    fmap f (C1 fa fb) = C1 fa (fmap f fb)
    fmap f (C2 a b1 b2) = C2 a (f b1) (f b2)
    fmap f (C3 ct3 b) = C3 (fmap f ct3) (f b)