{-# OPTIONS_GHC -Wincomplete-patterns #-}
module Gy01 where

xor :: Bool -> Bool -> Bool
xor True False = True
xor False True = True 
xor _ _ = False

xor' :: Bool -> Bool -> Bool
xor' x y = x /= y

xor'' :: Bool -> Bool -> Bool
xor'' x y = case x of
    True -> not y
    False -> y

id' :: a -> a
id' x = x

maxOf :: Ord a => a -> a -> a -> a
maxOf x y z = max x (max y z)

f1 :: (a, (b, (c ,d))) -> (b,c)
f1 p = (fst (snd p), fst (snd (snd p)))

f1' :: (a, (b, (c ,d))) -> (b,c)
f1' (a, (b, (c ,d))) = (b,c)

-- f1' :: (a, (b, (c ,d))) -> (b,c)
-- f1' (a, (b, (c ,d))) = (b,c)

-- f2 :: (a -> b -> c) -> b -> a -> c
-- f2 f a = f a

f3 :: (b -> c) -> (a -> b) -> a -> c
f3  f g a = f (g a)

f4 :: (a -> b -> c) -> b -> a -> c
f4 f b a = f a b

-- f9 :: Either a b -> Either b a
-- f9 (Left a) = b
-- f9 (Right b) = a

f11 :: (a -> c, b -> c) -> (Either a b -> c)
f11 (ac, bc) (Left a) = ac a
f11 (ac, bc) (Right b) = bc b

map' :: (a -> b) -> [a] -> [b]
map' f [] = []
map' f xs = [f x | x <- xs]

map'' :: (a -> b) -> [a] -> [b]
map'' f xs = foldr (\x rec -> f x : rec) [] xs

data Color = RGB Int Int Int | HSL Int Int Int deriving Show

data List a = Nil | Cons a (List a) deriving Show

instance Eq Color where
    (==) :: Color -> Color -> Bool
    RGB r g b == RGB r' g' b' = r == r' && g == g' && b == b' 
    HSL h s l == HSL h' s' l' = h == h' && s == s' && l == l' 
    _ == _ = False

instance (Eq a) => Eq (List a) where
    (==) :: List a -> List a -> Bool
    Nil == Nil = True
    Cons a as == Cons a' as' = a == a && as == as